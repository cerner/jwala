var HealthComponent = React.createClass({
    render: function () {
        return React.DOM.div({id: "newMessageInput"},
            React.DOM.span({className: "messageText"}, "Message Text"),
            React.DOM.br(),
            React.DOM.input({
                type: "textbox",
                size: "256",
                onChange: this.handleNewMessageTextChange,
                value: this.state.newMessageText,
                className: "newMessageText"
            }),
            React.DOM.label({className: "newMessageFail"},
                React.DOM.input({
                    type: "checkbox",
                    onChange: this.handleShouldFailChange,
                    checked: this.state.shouldFail
                }),
                "Should Fail"),
            React.DOM.br(),
            React.DOM.br(),
            React.DOM.input({
                id: "newMessageButton",
                type: "button",
                value: "Send Message",
                onClick: this.handleInsertNewMessage
            }),
            React.DOM.input({
                id: "loadCurrentStateButton",
                type: "button",
                value: "Get Current Status",
                onClick: this.loadStateFromServer
            }),
            React.DOM.br(),
            React.DOM.br(),
            React.DOM.br(),
            HealthData({health: this.state.health}));
    },
    componentWillMount: function () {
        this.loadStateFromServer();
    },

    componentDidMount: function() {
        this.runComponentDidUpdateCallback();
    },

    componentDidUpdate: function() {
        this.runComponentDidUpdateCallback();
    },

    runComponentDidUpdateCallback: function() {
        if (this.props.componentDidUpdateCallback !== undefined) {
            this.props.componentDidUpdateCallback();
        }
    },

    loadStateFromServer: function () {
        healthService.getHealth().bind(this).then(function (responseData) {
            this.updateHealthData(responseData, this.state.newMessageText);
        }).caught(function (e) {
            console.error("Uhoh again " + e);
        });
    },
    updateHealthData: function (health, messageText) {
        this.setState({
            health: health,
            newMessageText: ""
        });
    },
    getInitialState: function () {
        return {
            health: healthService.getDefaultHealth("Unknown", "-"),
            newMessageText: "",
            shouldFail: false
        };
    },
    handleShouldFailChange: function () {
        console.log("Fail was " + this.state.shouldFail);
        this.setState({shouldFail: !this.state.shouldFail});
    },
    handleNewMessageTextChange: function (e) {
        this.setState({newMessageText: e.target.value});
    },
    handleInsertNewMessage: function () {
        healthService.checkHealth(this.state.newMessageText, this.state.shouldFail).bind(this).then(function (responseData) {
            this.updateHealthData(responseData, this.state.newMessageText);
        }).caught(function (e) {
            console.error("uhoh " + e);
        });
    },
    displayName: "HealthStatus"
});

var HealthData = React.createClass({
    render: function () {
        console.log("Rendering HealthData");
        try {
            var asOfString = new Date(this.props.health.asOfDate).toLocaleString();
        } catch (e) {
            var asOfString = "Unknown";
        }

        return React.DOM.div({id: "healthStatus"},
            StatusResults(),
            StatusMessage({message: this.props.health.message}),
            MachineInfo({machineInfo: this.props.health.machineInfo}),
            Timings({timings: this.props.health.timings}),
            React.DOM.div({className: "asOf"},
                React.DOM.span({className: "statusLabel"}, "As of: "),
                React.DOM.span({className: "statusValue"}, asOfString))
        );
    },
    displayName: "HealthData"
});

var StatusMessage = React.createClass({
    render: function() {
        console.log("Rendering StatusMessage");
        return React.DOM.div({id : "currentStatus"},
            React.DOM.div(null,
                React.DOM.span({className : "statusLabel"}, "Message ID: "),
                React.DOM.span({className : "statusValue"}, this.props.message.messageID)),
            React.DOM.div(null,
                React.DOM.span({className : "statusLabel"}, "Message Text: "),
                React.DOM.span({className : "statusValue"}, this.props.message.messageText)));
    },
    displayName: "StatusMessage"
});

var MachineInfo = React.createClass({
    render: function () {
        console.log("Rendering MachineInfo");
        return React.DOM.div({className: "machineInfo"},
            React.DOM.div({className: "jvmInstanceName"},
                React.DOM.span({className: "statusLabel"}, "JVM Instance Name: "),
                React.DOM.span({className: "statusValue"}, this.props.machineInfo.jvmInstanceName)),
            React.DOM.div({className: "machineName"},
                React.DOM.span({className: "statusLabel"}, "Machine Name: "),
                React.DOM.span({className: "statusValue"}, this.props.machineInfo.machineName)),
            React.DOM.div({className: "httpListenPort"},
                React.DOM.span({className: "statusLabel"}, "HTTP Listen Port: "),
                React.DOM.span({className: "statusValue"}, this.props.machineInfo.httpListenPort)),
            React.DOM.div({className: "jvmPid"},
                React.DOM.span({className: "statusLabel"}, "JVM PID: "),
                React.DOM.span({className: "statusValue"}, this.props.machineInfo.jvmPid)),
            UpTime({upTime: this.props.machineInfo.upTime})
        );
    },
    displayName: "MachineInfo"
});

var Timings = React.createClass({
    render: function () {
        console.log("Rendering Timings");
        return React.DOM.div({className: "timings"},
            React.DOM.div({className: "serviceElapsedTime"},
                React.DOM.span({className: "statusLabel"}, "Service Execution Time (" + this.props.timings.serverTime.unit + ") : "),
                React.DOM.span({className: "statusValue"}, this.props.timings.serverTime.elapsedTime)),
            React.DOM.div({className: "dbElapsedTime"},
                React.DOM.span({className: "statusLabel"}, "DB Read Execution Time (" + this.props.timings.dbTime.unit + ") : "),
                React.DOM.span({className: "statusValue"}, this.props.timings.dbTime.elapsedTime)),
            React.DOM.div({className: "jmsElapsedTime"},
                React.DOM.span({className: "statusLabel"}, "JMS Send/Receive Execution Time (" + this.props.timings.jmsTime.unit + ") : "),
                React.DOM.span({className: "statusValue"}, this.props.timings.jmsTime.elapsedTime))
        );
    },
    displayName: "Timings"
});

var UpTime = React.createClass({
    render: function () {
        console.log("Rendering UpTime");
        return React.DOM.div({className: "upTime"},
            React.DOM.span({className: "statusLabel"}, "UpTime (minutes): "),
            React.DOM.span({className: "statusValue"}, this.props.upTime.timeInMinutes)
        );
    },
    displayName: "UpTime"
});

var StatusResults = React.createClass({
    render: function () {
        return React.DOM.span({className: "statusResults"}, "Response Data");
    },
    displayName: "StatusResults"
});