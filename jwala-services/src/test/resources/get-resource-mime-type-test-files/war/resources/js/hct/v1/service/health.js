var healthService = {
    checkHealth: function(message, shouldFail) {
        return serviceFoundation.get(this.uri(shouldFail) + "?message="+message, 'json');
    },
    getHealth: function() {
        return serviceFoundation.get('services/rest/v1/status', 'json');
    },
    getDefaultHealth: function(unknownText, unknownSymbol) {
        return {
            message : {
                messageText : unknownText,
                messageID : unknownSymbol
            },
            machineInfo : {
                upTime : {
                    timeInMinutes : unknownSymbol
                },
                jvmInstanceName : unknownText,
                jvmPid : unknownSymbol,
                machineName : unknownText,
                httpListenPort : unknownSymbol
            },
            asOfDate : unknownText,
            timings : {
                serverTime : {
                    unit : unknownText,
                    elapsedTime : unknownSymbol
                },
                dbTime : {
                    unit : unknownText,
                    elapsedTime : unknownSymbol
                },
                jmsTime : {
                    unit : unknownText,
                    elapsedTime : unknownSymbol
                }
            }
        }
    },
    uri: function (shouldFail) {
        return (shouldFail) ?
            'services/rest/v1/status/testXaLrco' :
            'services/rest/v1/status';
    }
};