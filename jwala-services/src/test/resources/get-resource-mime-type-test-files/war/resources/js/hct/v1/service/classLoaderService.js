var classLoaderService = {
    /**
     * Usage Ex: getClasses("localhost", "/hct", "stp", "Webapp")
     *
     * Notes:
     *
     * You can specify ‘Webapp’, ‘Common’, ‘System’, ‘Bootstrap’ for type.
     * You can specify any other context loaded in the JVM – ex. /hct,  /manager,  or /SF-LTST-N9SF/dynamic.
     * It can inspect any ClassLoader.
     */
    getClasses: function(host, context, service, type) {
        return serviceFoundation.get("services/rest/v1/classes?host=" + host + "&context=" + context + "&service=" + service + "&type=" + type, "json");
    }
}