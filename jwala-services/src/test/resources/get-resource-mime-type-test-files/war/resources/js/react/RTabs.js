/**
 * A React Tab component.
 *
 * Usage:
 *
 * var reactContent = <div>Last Name:<input/></div>;
 * var metaData = {tabs:[{label:"First Tab", content:"The quick and the dead..."}, {label:"2nd Tab", content:reactContent}, {label:"3rd Tab", content:"Yahoo!"}]};
 *
 * React.render(<RTabs metaData={metaData}/>, document.getElementById("table-container"));
 */
var RTabs = React.createClass({
    getInitialState: function() {
        return {tabIndex: 0}
    },
    render: function() {

        var tabs = [];

        for (var i = 0; i < this.props.metaData.tabs.length; i++) {
            var tab = this.props.metaData.tabs[i];
            var active = (this.state.tabIndex === i);
            tabs.push(React.createElement(Tab, {idx:i, key:tab.label, active:active, tabClickCallback:this.tabClickCallback}, tab.label));
        }

        var tabContent = React.createElement(TabContent,
                                             null,
                                             this.props.metaData.tabs[this.state.tabIndex].content);

        var tabsContainer = React.createElement("div", {className:"tabsContainer"}, tabs);
        return React.createElement("div", {className:"tabs"}, tabsContainer, tabContent);
    },
    tabClickCallback: function(idx) {
        this.setState({tabIndex: idx});
    }
});

var Tab = React.createClass({
    render: function() {
        var className = this.props.active ? "tab active" : "tab";
        return React.createElement("div", {className:className, onClick:this.onClick}, this.props.children);
    },
    onClick: function() {
        this.props.tabClickCallback(this.props.idx);
    }
});

var TabContent = React.createClass({
    render: function() {
        return React.createElement("div", {className:"tabContent"}, this.props.children);
    }
});